package kisicek.com.adminapp

class Item2 {
    var id:Int
    var price:Double
    var category:String


    constructor(id:Int, price:Double, category:String)
    {
        this.id=id
        this.price=price
        this.category=category

    }
}