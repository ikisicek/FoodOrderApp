package kisicek.com.adminapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.activity_item.*
import kotlinx.android.synthetic.main.activity_item_act3.*
import kotlinx.android.synthetic.main.activity_reg.*
import kotlinx.android.synthetic.main.item_row3.*

class ItemAct3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item_act3)

        var bill_no:String=intent.getStringExtra("bill_no")
        var url="http://192.168.64.2/salesweb/NOVO_get_billdet2.php?bill_no="+bill_no
        var list=ArrayList<Item3>()

        var rq:RequestQueue=Volley.newRequestQueue(this )
        var jar=JsonArrayRequest(Request.Method.GET, url, null, Response.Listener { response ->

            for (x in 0..response.length()-1)
                list.add(Item3(response.getJSONObject(x).getInt("bill_no"), response.getJSONObject(x).getString("bill_date") ,response.getJSONObject(x).getString("name")))

            var adp=ItemAdapter3(this, list)
            item_rv3.layoutManager= LinearLayoutManager(this)
            item_rv3.adapter=adp




        }, Response.ErrorListener { error ->

            Toast.makeText(this, error.message, Toast.LENGTH_LONG).show()

        })

        rq.add(jar)
    }


}
