package kisicek.com.adminapp

class Item {
    var bill_no:Int
    var itemid:Int
    var qty:Int
    var product:String


    constructor(bill_no:Int, itemid:Int, qty:Int, product:String)
    {
        this.bill_no=bill_no
        this.itemid=itemid
        this.qty=qty
        this.product=product


    }
}