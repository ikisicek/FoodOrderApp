package kisicek.com.adminapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.noviproizvod_btn
import kotlinx.android.synthetic.main.activity_reg.*

class RegAct : AppCompatActivity() {

    internal lateinit var sp : Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reg)

        //padajuća lista:
        sp = findViewById<Spinner>(R.id.spinner)
        val countries = arrayOf("Pizza", "Sandwich", "Salata", "Sokovi")
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, countries)
        sp.adapter = adapter

        novi_proizvod.setOnClickListener {

            var url="http://192.168.64.2/salesweb/admin_add_product.php?id"+reg_id.text.toString()+"&product="+reg_name.text.toString()+
            "&price="+reg_price.text.toString() + "&category="+reg_cat.text.toString() + "&details="+reg_cat.text.toString() +"&photo="+reg_photo.text.toString()

            var rq:RequestQueue=Volley.newRequestQueue(this)
            var sr=StringRequest(Request.Method.GET, url, Response.Listener { response ->

                if(response.equals("0"))
                    Toast.makeText(this, "Proizvod već postoji", Toast.LENGTH_LONG).show()
                else
                    Toast.makeText(this, "Proizvod dodan", Toast.LENGTH_LONG).show()
                var i= Intent(this, MainActivity::class.java)
                startActivity(i)


            }, Response.ErrorListener { error ->

                Toast.makeText(this, error.message, Toast.LENGTH_LONG).show()

            })
            rq.add(sr)
        }


    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.my_menu2, menu)
        return super.onCreateOptionsMenu(menu)
    }
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {

        if (item?.itemId == R.id.item_menu) {
            var i = Intent(this, MainActivity::class.java)
            startActivity(i)
        }
        return super.onOptionsItemSelected(item)
    }
}
