package kisicek.com.adminapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_item.*
import kotlinx.android.synthetic.main.activity_item_act2.*

class ItemAct2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item_act2)

        var product:String=intent.getStringExtra("product")
        var url="http://192.168.64.2/salesweb/admin_product_det.php?product="+product
        var list=ArrayList<Item2>()

        var rq: RequestQueue = Volley.newRequestQueue(this )
        var jar= JsonArrayRequest(Request.Method.GET, url, null, Response.Listener { response ->

            for (x in 0..response.length()-1)
                list.add(Item2(response.getJSONObject(x).getInt("id"), response.getJSONObject(x).getDouble("price"),
                    response.getJSONObject(x).getString("category")))

            var adp=ItemAdapter2(this,list)
            item_rv2.layoutManager= LinearLayoutManager(this)
            item_rv2.adapter=adp




        }, Response.ErrorListener { error ->

            Toast.makeText(this, error.message, Toast.LENGTH_LONG).show()

        })

        rq.add(jar)

    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.my_menu2, menu)
        return super.onCreateOptionsMenu(menu)
    }
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {

        if (item?.itemId == R.id.item_menu) {
            var i = Intent(this, HomeAct2::class.java)
            startActivity(i)
        }
        return super.onOptionsItemSelected(item)
    }
}
