package kisicek.com.adminapp

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.item_row.view.*
import kotlinx.android.synthetic.main.item_row2.view.*

class ItemAdapter2 (var context: Context, var list:ArrayList<Item2>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onBindViewHolder(p0: RecyclerView.ViewHolder, p1: Int) {
        (p0 as ItemHolder).bind(list[p1].id, list[p1].price, list[p1].category)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): RecyclerView.ViewHolder {
        var v: View = LayoutInflater.from(context).inflate(R.layout.item_row2, p0, false)
        return ItemHolder(v)

    }

    class ItemHolder(itemView: View): RecyclerView.ViewHolder(itemView)
    {
        fun bind(n:Int, p:Double, u:String)
        {
            itemView.item_id.text=n.toString()
            itemView.item_price.text=p.toString()
            itemView.item_cat.text=u
        }

    }
}