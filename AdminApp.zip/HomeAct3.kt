package kisicek.com.adminapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.activity_home_act3.*
import kotlinx.android.synthetic.main.activity_main.*

class HomeAct3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_act3)

        var url= "http://192.168.64.2/salesweb/get_bill2.php"
        var list=ArrayList<String>()
        var rq:RequestQueue=Volley.newRequestQueue(this)
        var jar=JsonArrayRequest(Request.Method.GET, url,null, Response.Listener { response ->

            for(x in 0..response.length()-1)
                list.add(response.getJSONObject(x).getString("bill_no"))

            var adp=ArrayAdapter(this, R.layout.my_textview, list)
            home_bill2.adapter=adp

        }, Response.ErrorListener { error ->
            Toast.makeText(this, error.message, Toast.LENGTH_LONG).show()

        })

        rq.add(jar)

        home_bill2.setOnItemClickListener { adapterView, view, i, int ->

            var bill_no:String=list[i]
            var obj= Intent(this, ItemAct3 ::class.java)
            obj.putExtra("bill_no", bill_no)
            startActivity(obj)

        }


    }
}

