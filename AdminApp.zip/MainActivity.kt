package kisicek.com.adminapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        narudzba_btn.setOnClickListener {
            var i=Intent(this, HomeAct::class.java)
            startActivity(i)
        }

        proizvodi_btn.setOnClickListener {
            var i=Intent(this, HomeAct2::class.java)
            startActivity(i)
        }

        noviproizvod_btn.setOnClickListener {
            var i=Intent(this, RegAct::class.java)
            startActivity(i)
        }

        racuni_btn.setOnClickListener {
            var i=Intent(this, HomeAct3::class.java)
            startActivity(i)
        }
    }
}
