package kisicek.com.adminapp

class Item3 {
    var bill_no:Int
    var bill_date:String
    var name:String



    constructor(bill_no:Int, bill_date:String, name:String)
    {
        this.bill_no=bill_no
        this.name=name
        this.bill_date=bill_date



    }
}