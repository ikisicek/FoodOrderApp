package kisicek.com.adminapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import kotlin.collections.ArrayList
import kotlin.concurrent.schedule

class HomeAct : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        var url= "http://192.168.64.2/salesweb/get_bill.php"
        var list=ArrayList<String>()
        var rq:RequestQueue=Volley.newRequestQueue(this)
        var jar=JsonArrayRequest(Request.Method.GET, url,null, Response.Listener { response ->

            for(x in 0..response.length()-1)
                list.add(response.getJSONObject(x).getString("bill_no"))

            var adp=ArrayAdapter(this, R.layout.my_textview, list)
            home_bill.adapter=adp

        }, Response.ErrorListener { error ->
            Toast.makeText(this, error.message, Toast.LENGTH_LONG).show()

        })

        rq.add(jar)

        home_bill.setOnItemClickListener { adapterView, view, i, int ->

                var bill_no:String=list[i]
                var obj= Intent(this, ItemAct ::class.java)
                obj.putExtra("bill_no", bill_no)
                startActivity(obj)

            }

            narudzba_refresh_btn.setOnClickListener {
                var i = Intent(this, HomeAct::class.java)
                startActivity(i)
        }



        }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.my_menu2, menu)
        return super.onCreateOptionsMenu(menu)
    }
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {

        if (item?.itemId == R.id.item_menu) {
            var i = Intent(this, MainActivity::class.java)
            startActivity(i)
        }
        return super.onOptionsItemSelected(item)
    }

    }

