<?php

$con=new mysqli("localhost","root","ivan","salesweb");

$st_check=$con->prepare("select * from users where name=?");
$st_check->bind_param("s", $_GET["name"]);
$st_check->execute();
$rs=$st_check->get_result();
if($rs->num_rows==0)
{
$st=$con->prepare("insert into users values(?,?)");
$st->bind_param("ss",$_GET["password"],$_GET["name"]);
$st->execute();
echo "1";
}
else
    echo "0";
?>