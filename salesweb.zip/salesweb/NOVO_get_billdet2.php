<?php

$con=new mysqli("localhost", "root", "ivan", "salesweb");
$st=$con->prepare("select bill_no, bill_date, name from bill where bill_no=?");
$st->bind_param("s", $_GET["bill_no"]);
$st->execute();
$rs=$st->get_result();
$arr=array();
while ($row=$rs->fetch_assoc())
{
    array_push($arr, $row);
}

echo json_encode($arr);
