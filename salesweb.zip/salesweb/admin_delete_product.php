<?php

$con=new mysqli("localhost","root","ivan","salesweb");
$st_check=$con->prepare("delete from bill_det where bill_no=?");
$st_check->bind_param("i", $_GET["bill_no"]);
$st_check->execute();