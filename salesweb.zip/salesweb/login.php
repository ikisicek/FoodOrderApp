<?php

$con=new mysqli("localhost", "root", "ivan", "salesweb");
$st_check=$con->prepare("select * from users where password=? and name=?");
$st_check->bind_param("ss", $_GET["password"], $_GET["name"]);
$st_check->execute();
$rs=$st_check->get_result();
if($rs->num_rows==0)
    echo "0";
else
    echo "1";