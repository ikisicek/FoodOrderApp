<?php

$con=new mysqli("localhost","root","ivan","salesweb");

$st_check=$con->prepare("select * from items where id=?");
$st_check->bind_param("i", $_GET["id"]);
$st_check->execute();
$rs=$st_check->get_result();
if($rs->num_rows==0)
{
$st=$con->prepare("insert into items values(?,?,?,?,?,?)");
$st->bind_param("isdsss",$_GET["id"],$_GET["product"], $_GET["price"], $_GET["category"],$_GET["photo"], $_GET["details"]);
$st->execute();
echo "1";
}
else
    echo "0";
?>
