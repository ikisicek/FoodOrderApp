<?php

$con=new mysqli("localhost","root","ivan","salesweb");

$st_check=$con->prepare("SELECT id, product, price, qty, name from temp_order INNER JOIN items on items.id=temp_order.itemid where name=?");
$st_check->bind_param("s", $_GET["name"]);
$st_check->execute();
$rs=$st_check->get_result();
$arr=array();
while($row=$rs->fetch_assoc())
{
    array_push($arr, $row);
}

echo json_encode($arr);

