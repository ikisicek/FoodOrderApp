<?php

$con=new mysqli("localhost","root","ivan","salesweb");
$st_check=$con->prepare("delete from temp_order where name=?");
$st_check->bind_param("s", $_GET["name"]);
$st_check->execute();