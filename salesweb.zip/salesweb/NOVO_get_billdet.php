<?php

$con=new mysqli("localhost", "root", "ivan", "salesweb");
$st=$con->prepare("select bill_no, itemid, qty, product from bill_det inner join items on bill_det.itemid=items.id where bill_no=?");
$st->bind_param("s", $_GET["bill_no"]);
$st->execute();
$rs=$st->get_result();
$arr=array();
while ($row=$rs->fetch_assoc())
{
    array_push($arr, $row);
}

echo json_encode($arr);
