<?php

//FILE ZA RASPOREĐIVANJE KATEGORIJA računa
$con=new mysqli("localhost", "root", "ivan", "salesweb");
$st_check=$con->prepare("select distinct bill_no from bill_det");
$st_check->execute();
$rs=$st_check->get_result();
$arr=array();
while ($row=$rs->fetch_assoc())
{
    array_push($arr, $row);
}
echo json_encode($arr);

