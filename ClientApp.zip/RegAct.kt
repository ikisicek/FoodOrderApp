package kisicek.com.salesapp

import android.app.DownloadManager
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import android.content.Intent

import com.squareup.picasso.Downloader
import com.squareup.picasso.Request
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_reg.*

class RegAct : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reg)

        reg_signup.setOnClickListener {

        //PROVJERA JE LI PASSWORD I CONFIRM PASSWORD ISTO
        if (reg_password.text.toString().equals(reg_confirm.text.toString()))
        {


            var url:String = "http://192.168.64.2/salesweb/add_user.php?name="+reg_name.text.toString() + "&password="+reg_password.text.toString()

            var rq:RequestQueue=Volley.newRequestQueue(this)
            var sr=StringRequest(com.android.volley.Request.Method.GET,url,Response.Listener { response ->

                if (response.equals("0"))
                    Toast.makeText(this,"Korisnik već postoji",Toast.LENGTH_LONG).show()
                else
                {
                    UserInfo.mobile=reg_name.text.toString()
                    var i=Intent(this, HomeAct::class.java)
                    startActivity(i)
                }
                    //Toast.makeText(this,"Korisnik kreiran",Toast.LENGTH_LONG).show()

            }, Response.ErrorListener { error ->
                Toast.makeText(this,error.message,Toast.LENGTH_LONG).show()

            })

            rq.add(sr)
        }
        else

                Toast.makeText(this,"Lozinke si ne odgovaraju",Toast.LENGTH_LONG).show()

        }

    }
}
