package kisicek.com.salesapp
//MODEL: (IZBACENE SLIEK!!
class Item {

    var id:Int
    var product:String
    var price:Double
    var photo:String
    var details:String

    constructor(id:Int, product:String, price:Double, photo:String, details:String)
    {
        this.id=id
        this.product=product
        this.price=price
        this.photo=photo
        this.details=details
    }
}