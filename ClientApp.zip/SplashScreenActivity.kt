package kisicek.com.salesapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.animation.AnimationUtils
import kotlinx.android.synthetic.main.activity_splash_screen.*

class SplashScreenActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

       splash_image_logo_restoran.setOnClickListener {
           val bounceAnimation = AnimationUtils.loadAnimation(this, R.anim.bounce)
           splash_image_logo_restoran.startAnimation(bounceAnimation)
       }
//
        val background = object : Thread(){
            override fun run() {
                try {

                    val bounceAnimation = AnimationUtils.loadAnimation(this@SplashScreenActivity, R.anim.bounce)
                    splash_image_logo_restoran.startAnimation(bounceAnimation)

                    Thread.sleep(5000)



                    val intent = Intent(baseContext, MainActivity::class.java)
                    startActivity(intent)
                } catch (e: Exception){
                    e.printStackTrace()
                }
            }
        }

        background.start()
    }
}
