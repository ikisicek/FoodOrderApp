package kisicek.com.salesapp

class UserInfo
{
    companion object {
        var mobile:String=""
        var itemId:Int=0
        var qty:Int=0

    }
}