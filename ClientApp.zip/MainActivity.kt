package kisicek.com.salesapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import android.content.Intent
import android.support.v7.app.AlertDialog
import android.text.Html
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Toast
import android.widget.Toolbar
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_reg.*
import kotlinx.android.synthetic.main.my_textview.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        login_signup.setOnClickListener {

            val blinkanimation = AnimationUtils.loadAnimation(this, R.anim.blink)
            login_signup.startAnimation(blinkanimation)

            var i=Intent(this,RegAct::class.java)
            startActivity(i)

            //val  bounceAnimation = AnimationUtils.loadAnimation(this, R.anim.bounce)
            //textView.startAnimation(bounceAnimation)

        }

        login_btn.setOnClickListener {

            val blinkanimation = AnimationUtils.loadAnimation(this, R.anim.blink)
            login_btn.startAnimation(blinkanimation)

            var url:String = "http://192.168.64.2/salesweb/login.php?name="+login_name.text.toString() + "&password="+login_password.text.toString()

            var rq: RequestQueue = Volley.newRequestQueue(this)
            var sr= StringRequest(Request.Method.GET,url, Response.Listener { response ->

                if (response.equals("0"))
                    Toast.makeText(this,"Prijava nije uspjela", Toast.LENGTH_LONG).show()
                else
                {
                    UserInfo.mobile=login_name.text.toString()
                    var i=Intent(this, StartActivity::class.java)
                    startActivity(i)
                }
                //Toast.makeText(this,"Korisnik kreiran",Toast.LENGTH_LONG).show()

            }, Response.ErrorListener { error ->
                Toast.makeText(this,error.message, Toast.LENGTH_LONG).show()

            })

            rq.add(sr)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.menu_info, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if(item?.itemId == R.id.action_about){
            showInfo()
        }
        return true
    }

    private fun showInfo(){
        val dialogTitle = getString(R.string.about_title)
        val dialogMessage = getString(R.string.about_message)
        val builder = AlertDialog.Builder(this)
        builder.setTitle(dialogTitle)
        builder.setMessage(dialogMessage)
        builder.create().show()
    }
}

