package kisicek.com.salesapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_order.*

class OrderAct : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order)

        supportActionBar?.title = "NARUČENI PROIZVODI"

        var url="http://192.168.64.2/salesweb/get_temp.php?name=" + UserInfo.mobile

        var list=ArrayList<String>()
        var rq: RequestQueue = Volley.newRequestQueue(this)
        var jar= JsonArrayRequest(Request.Method.GET,url,null, Response.Listener { response ->


            for(x in 0..response.length()-1)
                list.add("Naziv     : " + response.getJSONObject(x).getString("product") + "\n" + "Cijena    : " + response.getJSONObject(x).getString("price") + "\n" + "Količina : " + response.getJSONObject(x).getString("qty"))

            var adp= ArrayAdapter(this, android.R.layout.simple_list_item_1, list )
            order_lv.adapter= adp

        }, Response.ErrorListener { error ->

            Toast.makeText(this, error.message, Toast.LENGTH_LONG).show()

        })
        rq.add(jar)

        dugme_povratak.setOnClickListener {
            var i=Intent(this,HomeAct::class.java)
            startActivity(i)
        }

        dugme_potvrda.setOnClickListener {
            var url="http://192.168.64.2/salesweb/confirm_order.php?name=" + UserInfo.mobile

            var rq:RequestQueue=Volley.newRequestQueue(this)
            var sr= StringRequest(Request.Method.GET,url, Response.Listener { response ->

                var i=Intent(this,TotalAct::class.java)
                i.putExtra("bno", response)
                startActivity(i)


            }, Response.ErrorListener { error ->
                Toast.makeText(this,error.message,Toast.LENGTH_LONG).show()
            })

            rq.add(sr)
        }

        dugme_odustani.setOnClickListener {
            var url="http://192.168.64.2/salesweb/cancel_order.php?name=" + UserInfo.mobile

            var rq:RequestQueue=Volley.newRequestQueue(this)
            var sr= StringRequest(Request.Method.GET,url, Response.Listener { response ->

                var i=Intent(this,HomeAct::class.java)
                startActivity(i)


            }, Response.ErrorListener { error ->
                Toast.makeText(this,error.message,Toast.LENGTH_LONG).show()
            })

            rq.add(sr)
        }

    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.my_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {

        if(item?.itemId==R.id.item_menu)
        {
            var i=Intent(this, HomeAct::class.java)
            startActivity(i)
        }

        if(item?.itemId==R.id.item_cancel)
        {
            var url="http://192.168.64.2/salesweb/cancel_order.php?name=" + UserInfo.mobile

            var rq:RequestQueue=Volley.newRequestQueue(this)
            var sr= StringRequest(Request.Method.GET,url, Response.Listener { response ->

                var i=Intent(this,HomeAct::class.java)
                startActivity(i)


            }, Response.ErrorListener { error ->
                Toast.makeText(this,error.message,Toast.LENGTH_LONG).show()
            })

            rq.add(sr)
        }

        //56.vid

        if (item?.itemId==R.id.item_confirm)
        {
            var url="http://192.168.64.2/salesweb/confirm_order.php?name=" + UserInfo.mobile

            var rq:RequestQueue=Volley.newRequestQueue(this)
            var sr= StringRequest(Request.Method.GET,url, Response.Listener { response ->

                var i=Intent(this,TotalAct::class.java)
                i.putExtra("bno", response)
                startActivity(i)


            }, Response.ErrorListener { error ->
                Toast.makeText(this,error.message,Toast.LENGTH_LONG).show()
            })

            rq.add(sr)
        }

        return super.onOptionsItemSelected(item)
    }
}
